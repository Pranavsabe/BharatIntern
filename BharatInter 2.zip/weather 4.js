document.getElementById('getWeather').addEventListener('click', getWeatherDetails);

document.getElementById('city').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        getWeatherDetails();
    }
});

function getWeatherDetails() {
    const city = document.getElementById('city').value;
    const apiKey = 'ab0bcdbfcb6faa3484d6edb6d36db8ef'; 
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                const weatherDetails = `
                    <h2>${data.name}, ${data.sys.country}</h2>
                    <p>Temperature: ${data.main.temp} °C</p>
                    <p>Weather: ${data.weather[0].description}</p>
                    <p>Humidity: ${data.main.humidity} %</p>
                    <p>Wind Speed: ${data.wind.speed} m/s</p>
                `;
                document.getElementById('weatherDetails').innerHTML = weatherDetails;
            } else {
                document.getElementById('weatherDetails').innerHTML = `<p>${data.message}</p>`;
            }
        })
        .catch(error => {
            document.getElementById('weatherDetails').innerHTML = `<p>Error: ${error.message}</p>`;
        });
}
